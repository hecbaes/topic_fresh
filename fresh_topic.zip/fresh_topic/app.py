from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os
import fitz  # PyMuPDF
import gensim
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from io import BytesIO
import base64

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
ALLOWED_EXTENSIONS = {'txt', 'pdf'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_pdf(pdf_path):
    text = ""
    with fitz.open(pdf_path) as doc:
        for page in doc:
            text += page.get_text()
    return text

def extract_text_from_txt(txt_path):
    with open(txt_path, 'r', encoding='utf-8') as file:
        text = file.read()
    return text

def process_text(text):
    # Process text for topic discovery
    # Example: Use gensim or other NLP library for topic modeling
    # Return topics and word map
    topics = ["Topic 1", "Topic 2", "Topic 3", "Topic 4", "Topic 5"]  # Example topics
    word_map = create_word_map(text)
    return topics, word_map

def create_word_map(text):
    # Create a word map using WordCloud or similar
    wordcloud = WordCloud(width=480, height=480, margin=0).generate(text)
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")
    plt.margins(x=0, y=0)
    plt.tight_layout(pad=0)

    img = BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    word_map = base64.b64encode(img.getvalue()).decode()
    return word_map

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            if filename.endswith('.pdf'):
                text = extract_text_from_pdf(file_path)
            else:
                text = extract_text_from_txt(file_path)

            topics, word_map = process_text(text)
            return render_template('results.html', topics=topics, word_map=word_map)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)

